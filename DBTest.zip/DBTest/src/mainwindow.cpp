#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QSqlQueryModel>

#include "CppSQLite3.h"

MainWindow::MainWindow(QWidget *parent)
    :   QMainWindow(parent),
        ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    AddRows();
    AddLines();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::AddRows()
{
    QSqlDatabase db(QSqlDatabase::addDatabase("QSQLITE"));
    db.setDatabaseName("D:\\Learn\\Github\\DBTest\\src\\testDB");
    db.open();
    QSqlQueryModel* model = new QSqlQueryModel;
    model->setQuery("SELECT lang_id, lang_name FROM languages", db);
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("NAME"));

    ui->tableView->setModel(model);
    ui->tableView->show();
    db.close();
}

void MainWindow::AddLines()
{
    ui->comboBox->clear();
    CppSQLite3DB db;
    db.open("D:\\Learn\\Github\\DBTest\\src\\testDB");
    CppSQLite3Query query(db.execQuery("SELECT * FROM languages"));
    while (!query.eof())
    {
        std::string item(std::to_string(query.getIntField("lang_id")) +
                         " - " +
                         query.getStringField("lang_name"));
        ui->comboBox->addItem(QString::fromStdString(item));
        query.nextRow();
    }
    query.finalize();
    db.close();
}

void MainWindow::on_pushButton_clicked()
{
    CppSQLite3DB db;
    db.open("D:\\Learn\\Github\\DBTest\\src\\testDB");
    const std::string sql("INSERT INTO languages VALUES(" +
                          ui->lineEdit->text().toStdString() + ", '" +
                          ui->lineEdit_2->text().toStdString() + "')");
    db.execDML(sql.c_str());
    db.close();

    AddLines();
}
