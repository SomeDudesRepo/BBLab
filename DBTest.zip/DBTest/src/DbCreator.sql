/* Users */
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS users_audit;
DROP TABLE IF EXISTS users_session_log;

CREATE TABLE users
(
	user_id VARCHAR(30) PRIMARY KEY,
	password VARCHAR(80) NOT NULL,
	validity TEXT NOT NULL,
	change_password SMALLINT NOT NULL,
	active SMALLINT NOT NULL,
	log_user_ID VARCHAR(30) NOT NULL,
	timestamp TEXT NOT NULL
);

CREATE TABLE users_audit
(
	user_id VARCHAR(30) NOT NULL,
	password VARCHAR(80) NOT NULL,
	validity TEXT NOT NULL,
	change_password SMALLINT NOT NULL,
	active SMALLINT NOT NULL,
	log_user_ID VARCHAR(30) NOT NULL,
	timestamp TEXT NOT NULL,
	PRIMARY KEY(user_id, timestamp)
);

CREATE TABLE users_session_log
(
	user_id VARCHAR(30) NOT NULL,
	entry_timestamp TEXT NOT NULL,
	exit_timestamp TEXT,
	exit_reason SMALLINT,
	PRIMARY KEY(user_id, entry_timestamp, exit_timestamp)
);

DROP TRIGGER IF EXISTS users_audit_trig;
CREATE TRIGGER users_audit_trig AFTER INSERT ON users_audit
BEGIN
	INSERT OR REPLACE INTO users(user_id, password, validity, change_password, active, log_user_ID, timestamp) 
	VALUES(NEW.user_id, NEW.password, NEW.validity, NEW.change_password, NEW.active, NEW.log_user_ID, NEW.timestamp);
END;

/* Languages */

DROP TABLE IF EXISTS languages;
DROP TABLE IF EXISTS languages_audit;

CREATE TABLE languages
(
	lang_id INT PRIMARY KEY,
	lang_name VARCHAR(30) NOT NULL,
	active SMALLINT NOT NULL,
	log_user_id VARCHAR(30) NOT NULL,
	timestamp TEXT NOT NULL
);

CREATE TABLE languages_audit
(
	lang_id INT NOT NULL,
	lang_name VARCHAR(30) NOT NULL,
	active SMALLINT NOT NULL,
	log_user_id VARCHAR(30) NOT NULL,
	timestamp TEXT NOT NULL,
	PRIMARY KEY(lang_id, timestamp)
);

DROP TRIGGER IF EXISTS languages_audit_trig;
CREATE TRIGGER languages_audit_trig AFTER INSERT ON languages_audit
BEGIN
	INSERT OR REPLACE INTO languages(lang_id, lang_name, active, log_user_id, timestamp) 
	VALUES(NEW.lang_id, NEW.lang_name, NEW.active, NEW.log_user_id, NEW.timestamp);
END;
